package android.app;

public class AppComponentFactory {
    static {
        throw new NoClassDefFoundError();
    }
}

