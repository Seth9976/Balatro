package a0;

public final class c extends RuntimeException {
    public c(String s) {
        super(s);
    }

    public c(Throwable throwable0) {
        super(throwable0);
    }
}

