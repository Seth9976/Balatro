package a0;

import android.content.Context;
import java.util.List;

public interface a {
    List a();

    Object b(Context arg1);
}

