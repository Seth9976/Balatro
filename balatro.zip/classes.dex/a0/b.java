package a0;

public abstract class b {
    public static int a = 0x7F0D001B;  // string:androidx_startup "androidx.startup"

}

