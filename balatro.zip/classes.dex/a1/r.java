package a1;

import android.os.IInterface;

public interface r extends IInterface {
    void L();

    void r();
}

