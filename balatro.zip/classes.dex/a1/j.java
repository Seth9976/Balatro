package a1;

import com.google.android.gms.common.api.Status;

final class j extends e {
    final k a;

    j(k k0) {
        this.a = k0;
        super();
    }

    @Override  // a1.e
    public final void p(Status status0) {
        this.a.h(status0);
    }
}

