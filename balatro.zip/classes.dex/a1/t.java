package a1;

import android.os.IInterface;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.Status;

public interface t extends IInterface {
    void P(Status arg1);

    void S(GoogleSignInAccount arg1, Status arg2);

    void p(Status arg1);
}

