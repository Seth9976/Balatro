package a1;

import com.google.android.gms.common.api.Status;
import d1.a.b;
import d1.f;
import d1.k;

final class m extends n {
    m(f f0) {
        super(f0);
    }

    @Override  // com.google.android.gms.common.api.internal.BasePendingResult
    protected final k e(Status status0) {
        return status0;
    }

    @Override  // com.google.android.gms.common.api.internal.b
    protected final void n(b a$b0) {
        ((u)((i)a$b0).C()).f(new l(this), ((i)a$b0).k0());
    }
}

