package a1;

import com.google.android.gms.common.api.Status;
import d1.a.b;
import d1.f;

final class k extends n {
    k(f f0) {
        super(f0);
    }

    @Override  // com.google.android.gms.common.api.internal.BasePendingResult
    protected final d1.k e(Status status0) {
        return status0;
    }

    @Override  // com.google.android.gms.common.api.internal.b
    protected final void n(b a$b0) {
        ((u)((i)a$b0).C()).W(new j(this), ((i)a$b0).k0());
    }
}

