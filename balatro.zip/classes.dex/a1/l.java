package a1;

import com.google.android.gms.common.api.Status;

final class l extends e {
    final m a;

    l(m m0) {
        this.a = m0;
        super();
    }

    @Override  // a1.e
    public final void P(Status status0) {
        this.a.h(status0);
    }
}

