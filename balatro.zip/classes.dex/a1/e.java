package a1;

import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.Status;

public abstract class e extends s {
    @Override  // a1.t
    public void P(Status status0) {
        throw new UnsupportedOperationException();
    }

    @Override  // a1.t
    public void S(GoogleSignInAccount googleSignInAccount0, Status status0) {
        throw new UnsupportedOperationException();
    }

    @Override  // a1.t
    public void p(Status status0) {
        throw new UnsupportedOperationException();
    }
}

