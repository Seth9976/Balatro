package a1;

import com.google.android.gms.common.api.internal.b;
import d1.f;
import d1.k;
import x0.a;

abstract class n extends b {
    public n(f f0) {
        super(a.b, f0);
    }

    @Override  // e1.c
    public final void a(Object object0) {
        super.h(((k)object0));
    }
}

