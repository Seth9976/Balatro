package a;

import android.content.Context;

public interface b {
    void a(Context arg1);
}

