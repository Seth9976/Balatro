package a2;

abstract class e {
    static boolean a() [...] // 潜在的解密器
}

