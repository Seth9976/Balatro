package a2;

import c1.c;

public abstract class d {
    public static final c a;
    public static final c[] b;

    static {
        c c0 = new c("CLIENT_TELEMETRY", 1L);
        d.a = c0;
        d.b = new c[]{c0};
    }
}

