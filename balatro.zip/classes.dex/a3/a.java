package a3;

public interface a {
    Object get();
}

