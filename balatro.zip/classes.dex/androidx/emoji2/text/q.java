package androidx.emoji2.text;

public abstract class q {
}

