package androidx.emoji2.text;

public final class k implements Runnable {
    public final b e;

    public k(b j$b0) {
        this.e = j$b0;
    }

    @Override
    public final void run() {
        this.e.c();
    }
}

