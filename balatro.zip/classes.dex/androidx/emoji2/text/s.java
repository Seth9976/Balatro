package androidx.emoji2.text;

import android.text.PrecomputedText;

public abstract class s {
    public static boolean a(Object object0) {
        return object0 instanceof PrecomputedText;
    }
}

