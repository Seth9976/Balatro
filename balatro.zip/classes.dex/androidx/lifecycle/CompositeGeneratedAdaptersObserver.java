package androidx.lifecycle;

class CompositeGeneratedAdaptersObserver implements j {
    private final f[] a;

    CompositeGeneratedAdaptersObserver(f[] arr_f) {
        this.a = arr_f;
    }

    @Override  // androidx.lifecycle.j
    public void d(l l0, b h$b0) {
        new o();
        f[] arr_f = this.a;
        if(arr_f.length <= 0) {
            return;
        }
        f f0 = arr_f[0];
        throw null;
    }
}

