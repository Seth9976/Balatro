package androidx.lifecycle;

import android.view.View;
import w.a;

public abstract class e0 {
    public static void a(View view0, l l0) {
        view0.setTag(a.a, l0);
    }
}

