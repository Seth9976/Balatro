package androidx.lifecycle;

public interface c extends e {
}

