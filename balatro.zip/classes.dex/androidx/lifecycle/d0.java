package androidx.lifecycle;

public interface d0 {
    c0 l();
}

