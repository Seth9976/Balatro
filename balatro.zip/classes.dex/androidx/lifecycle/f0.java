package androidx.lifecycle;

import android.view.View;
import x.e;

public abstract class f0 {
    public static void a(View view0, d0 d00) {
        view0.setTag(e.a, d00);
    }
}

