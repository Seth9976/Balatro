package androidx.lifecycle;

import java.util.LinkedHashMap;
import java.util.Map;

public final class x extends y {
    private final Map d;

    public x() {
        this.d = new LinkedHashMap();
    }

    public final Map e() {
        return this.d;
    }
}

