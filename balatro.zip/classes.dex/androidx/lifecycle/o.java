package androidx.lifecycle;

import java.util.HashMap;
import java.util.Map;

public class o {
    private Map a;

    public o() {
        this.a = new HashMap();
    }
}

