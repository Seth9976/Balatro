package androidx.lifecycle;

class Lifecycling.1 implements j {
    final j a;

    @Override  // androidx.lifecycle.j
    public void d(l l0, b h$b0) {
        this.a.d(l0, h$b0);
    }
}

