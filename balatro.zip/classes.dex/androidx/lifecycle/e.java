package androidx.lifecycle;

interface e extends k {
    void a(l arg1);

    void b(l arg1);

    void c(l arg1);

    void e(l arg1);

    void f(l arg1);

    void g(l arg1);
}

