package androidx.lifecycle;

public interface q {
    void a(Object arg1);
}

