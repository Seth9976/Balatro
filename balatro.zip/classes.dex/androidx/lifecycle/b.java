package androidx.lifecycle;

public abstract class b {
    public static void a(c c0, l l0) {
    }

    public static void b(c c0, l l0) {
    }

    public static void c(c c0, l l0) {
    }

    public static void d(c c0, l l0) {
    }

    public static void e(c c0, l l0) {
    }
}

