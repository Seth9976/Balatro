package androidx.lifecycle;

class SingleGeneratedAdapterObserver implements j {
    SingleGeneratedAdapterObserver(f f0) {
    }

    @Override  // androidx.lifecycle.j
    public void d(l l0, b h$b0) {
        throw null;
    }
}

