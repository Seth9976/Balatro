package androidx.lifecycle;

public interface j extends k {
    void d(l arg1, b arg2);
}

