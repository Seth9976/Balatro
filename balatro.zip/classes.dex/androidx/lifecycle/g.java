package androidx.lifecycle;

import x.a;

public interface g {
    a a();
}

