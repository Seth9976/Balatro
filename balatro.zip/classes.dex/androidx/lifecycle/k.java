package androidx.lifecycle;

public interface k {
}

