package androidx.lifecycle;

public class p extends LiveData {
    @Override  // androidx.lifecycle.LiveData
    public void l(Object object0) {
        super.l(object0);
    }

    @Override  // androidx.lifecycle.LiveData
    public void n(Object object0) {
        super.n(object0);
    }
}

