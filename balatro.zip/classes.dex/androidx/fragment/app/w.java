package androidx.fragment.app;

import android.os.Bundle;
import z.c.c;

public final class w implements c {
    public final x a;

    public w(x x0) {
        this.a = x0;
    }

    @Override  // z.c$c
    public final Bundle a() {
        return this.a.O0();
    }
}

