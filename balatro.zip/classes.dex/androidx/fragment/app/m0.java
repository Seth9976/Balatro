package androidx.fragment.app;

import android.view.ViewGroup;

interface m0 {
    l0 a(ViewGroup arg1);
}

