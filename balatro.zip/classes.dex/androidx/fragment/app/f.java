package androidx.fragment.app;

import android.os.Bundle;
import z.c.c;

public final class f implements c {
    public final j a;

    public f(j j0) {
        this.a = j0;
    }

    @Override  // z.c$c
    public final Bundle a() {
        return this.a.P();
    }
}

