package androidx.fragment.app;

import android.os.Bundle;
import android.view.View;
import h.d;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

class r {
    private final CopyOnWriteArrayList a;
    private final x b;

    r(x x0) {
        this.a = new CopyOnWriteArrayList();
        this.b = x0;
    }

    void a(Fragment fragment0, Bundle bundle0, boolean z) {
        Fragment fragment1 = this.b.w0();
        if(fragment1 != null) {
            fragment1.G().v0().a(fragment0, bundle0, true);
        }
        Iterator iterator0 = this.a.iterator();
        if(iterator0.hasNext()) {
            Object object0 = iterator0.next();
            d.a(object0);
            throw null;
        }
    }

    void b(Fragment fragment0, boolean z) {
        this.b.t0().u();
        Fragment fragment1 = this.b.w0();
        if(fragment1 != null) {
            fragment1.G().v0().b(fragment0, true);
        }
        Iterator iterator0 = this.a.iterator();
        if(iterator0.hasNext()) {
            Object object0 = iterator0.next();
            d.a(object0);
            throw null;
        }
    }

    void c(Fragment fragment0, Bundle bundle0, boolean z) {
        Fragment fragment1 = this.b.w0();
        if(fragment1 != null) {
            fragment1.G().v0().c(fragment0, bundle0, true);
        }
        Iterator iterator0 = this.a.iterator();
        if(iterator0.hasNext()) {
            Object object0 = iterator0.next();
            d.a(object0);
            throw null;
        }
    }

    void d(Fragment fragment0, boolean z) {
        Fragment fragment1 = this.b.w0();
        if(fragment1 != null) {
            fragment1.G().v0().d(fragment0, true);
        }
        Iterator iterator0 = this.a.iterator();
        if(iterator0.hasNext()) {
            Object object0 = iterator0.next();
            d.a(object0);
            throw null;
        }
    }

    void e(Fragment fragment0, boolean z) {
        Fragment fragment1 = this.b.w0();
        if(fragment1 != null) {
            fragment1.G().v0().e(fragment0, true);
        }
        Iterator iterator0 = this.a.iterator();
        if(iterator0.hasNext()) {
            Object object0 = iterator0.next();
            d.a(object0);
            throw null;
        }
    }

    void f(Fragment fragment0, boolean z) {
        Fragment fragment1 = this.b.w0();
        if(fragment1 != null) {
            fragment1.G().v0().f(fragment0, true);
        }
        Iterator iterator0 = this.a.iterator();
        if(iterator0.hasNext()) {
            Object object0 = iterator0.next();
            d.a(object0);
            throw null;
        }
    }

    void g(Fragment fragment0, boolean z) {
        this.b.t0().u();
        Fragment fragment1 = this.b.w0();
        if(fragment1 != null) {
            fragment1.G().v0().g(fragment0, true);
        }
        Iterator iterator0 = this.a.iterator();
        if(iterator0.hasNext()) {
            Object object0 = iterator0.next();
            d.a(object0);
            throw null;
        }
    }

    void h(Fragment fragment0, Bundle bundle0, boolean z) {
        Fragment fragment1 = this.b.w0();
        if(fragment1 != null) {
            fragment1.G().v0().h(fragment0, bundle0, true);
        }
        Iterator iterator0 = this.a.iterator();
        if(iterator0.hasNext()) {
            Object object0 = iterator0.next();
            d.a(object0);
            throw null;
        }
    }

    void i(Fragment fragment0, boolean z) {
        Fragment fragment1 = this.b.w0();
        if(fragment1 != null) {
            fragment1.G().v0().i(fragment0, true);
        }
        Iterator iterator0 = this.a.iterator();
        if(iterator0.hasNext()) {
            Object object0 = iterator0.next();
            d.a(object0);
            throw null;
        }
    }

    void j(Fragment fragment0, Bundle bundle0, boolean z) {
        Fragment fragment1 = this.b.w0();
        if(fragment1 != null) {
            fragment1.G().v0().j(fragment0, bundle0, true);
        }
        Iterator iterator0 = this.a.iterator();
        if(iterator0.hasNext()) {
            Object object0 = iterator0.next();
            d.a(object0);
            throw null;
        }
    }

    void k(Fragment fragment0, boolean z) {
        Fragment fragment1 = this.b.w0();
        if(fragment1 != null) {
            fragment1.G().v0().k(fragment0, true);
        }
        Iterator iterator0 = this.a.iterator();
        if(iterator0.hasNext()) {
            Object object0 = iterator0.next();
            d.a(object0);
            throw null;
        }
    }

    void l(Fragment fragment0, boolean z) {
        Fragment fragment1 = this.b.w0();
        if(fragment1 != null) {
            fragment1.G().v0().l(fragment0, true);
        }
        Iterator iterator0 = this.a.iterator();
        if(iterator0.hasNext()) {
            Object object0 = iterator0.next();
            d.a(object0);
            throw null;
        }
    }

    void m(Fragment fragment0, View view0, Bundle bundle0, boolean z) {
        Fragment fragment1 = this.b.w0();
        if(fragment1 != null) {
            fragment1.G().v0().m(fragment0, view0, bundle0, true);
        }
        Iterator iterator0 = this.a.iterator();
        if(iterator0.hasNext()) {
            Object object0 = iterator0.next();
            d.a(object0);
            throw null;
        }
    }

    void n(Fragment fragment0, boolean z) {
        Fragment fragment1 = this.b.w0();
        if(fragment1 != null) {
            fragment1.G().v0().n(fragment0, true);
        }
        Iterator iterator0 = this.a.iterator();
        if(iterator0.hasNext()) {
            Object object0 = iterator0.next();
            d.a(object0);
            throw null;
        }
    }
}

