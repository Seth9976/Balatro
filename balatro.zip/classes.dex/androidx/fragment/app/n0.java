package androidx.fragment.app;

import android.util.AndroidRuntimeException;

final class n0 extends AndroidRuntimeException {
    public n0(String s) {
        super(s);
    }
}

