package androidx.fragment.app;

import android.content.Intent;
import androidx.core.util.a;

public final class h implements a {
    public final j a;

    public h(j j0) {
        this.a = j0;
    }

    @Override  // androidx.core.util.a
    public final void accept(Object object0) {
        this.a.R(((Intent)object0));
    }
}

