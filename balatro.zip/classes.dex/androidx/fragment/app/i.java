package androidx.fragment.app;

import a.b;
import android.content.Context;

public final class i implements b {
    public final j a;

    public i(j j0) {
        this.a = j0;
    }

    @Override  // a.b
    public final void a(Context context0) {
        this.a.S(context0);
    }
}

