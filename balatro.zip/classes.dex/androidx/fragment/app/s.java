package androidx.fragment.app;

import android.content.res.Configuration;
import androidx.core.util.a;

public final class s implements a {
    public final x a;

    public s(x x0) {
        this.a = x0;
    }

    @Override  // androidx.core.util.a
    public final void accept(Object object0) {
        this.a.P0(((Configuration)object0));
    }
}

