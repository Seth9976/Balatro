package androidx.fragment.app;

import androidx.core.app.f0;
import androidx.core.util.a;

public final class v implements a {
    public final x a;

    public v(x x0) {
        this.a = x0;
    }

    @Override  // androidx.core.util.a
    public final void accept(Object object0) {
        this.a.S0(((f0)object0));
    }
}

