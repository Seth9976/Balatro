package androidx.fragment.app;

import android.content.res.Configuration;
import androidx.core.util.a;

public final class g implements a {
    public final j a;

    public g(j j0) {
        this.a = j0;
    }

    @Override  // androidx.core.util.a
    public final void accept(Object object0) {
        this.a.Q(((Configuration)object0));
    }
}

