package androidx.fragment.app;

import androidx.core.app.d;
import androidx.core.util.a;

public final class u implements a {
    public final x a;

    public u(x x0) {
        this.a = x0;
    }

    @Override  // androidx.core.util.a
    public final void accept(Object object0) {
        this.a.R0(((d)object0));
    }
}

