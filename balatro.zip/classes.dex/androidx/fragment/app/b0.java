package androidx.fragment.app;

public interface b0 {
    void a(x arg1, Fragment arg2);
}

