package androidx.fragment.app;

import androidx.core.util.a;

public final class t implements a {
    public final x a;

    public t(x x0) {
        this.a = x0;
    }

    @Override  // androidx.core.util.a
    public final void accept(Object object0) {
        this.a.Q0(((Integer)object0));
    }
}

