package androidx.activity;

public interface l extends androidx.lifecycle.l {
    OnBackPressedDispatcher c();
}

