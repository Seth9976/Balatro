package androidx.activity;

public final class f implements Runnable {
    public final g e;

    public f(g g0) {
        this.e = g0;
    }

    @Override
    public final void run() {
        g.f(this.e);
    }
}

