package androidx.activity;

import android.view.View;
import k3.f;

public abstract class n {
    public static final void a(View view0, l l0) {
        f.e(view0, "<this>");
        f.e(l0, "onBackPressedDispatcherOwner");
        view0.setTag(m.a, l0);
    }
}

