package androidx.activity.result;

public interface d {
    ActivityResultRegistry h();
}

