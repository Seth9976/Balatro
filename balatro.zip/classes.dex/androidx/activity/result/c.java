package androidx.activity.result;

import androidx.core.app.b;

public abstract class c {
    public void a(Object object0) {
        this.b(object0, null);
    }

    public abstract void b(Object arg1, b arg2);

    public abstract void c();
}

