package androidx.activity;

import a.b;
import android.content.Context;

public final class d implements b {
    public final ComponentActivity a;

    public d(ComponentActivity componentActivity0) {
        this.a = componentActivity0;
    }

    @Override  // a.b
    public final void a(Context context0) {
        this.a.D(context0);
    }
}

