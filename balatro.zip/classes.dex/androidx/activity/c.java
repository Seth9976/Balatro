package androidx.activity;

import android.os.Bundle;

public final class c implements z.c.c {
    public final ComponentActivity a;

    public c(ComponentActivity componentActivity0) {
        this.a = componentActivity0;
    }

    @Override  // z.c$c
    public final Bundle a() {
        return this.a.C();
    }
}

