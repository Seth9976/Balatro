package androidx.core.util;

public interface a {
    void accept(Object arg1);
}

