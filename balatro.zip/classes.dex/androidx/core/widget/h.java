package androidx.core.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;

public interface h {
    void setSupportCompoundDrawablesTintList(ColorStateList arg1);

    void setSupportCompoundDrawablesTintMode(PorterDuff.Mode arg1);
}

