package androidx.core.content;

import androidx.core.util.a;

public interface b {
    void k(a arg1);

    void r(a arg1);
}

