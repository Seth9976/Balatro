package androidx.core.content;

import androidx.core.util.a;

public interface c {
    void p(a arg1);

    void q(a arg1);
}

