package androidx.core.view;

import android.view.WindowInsets.Builder;
import android.view.WindowInsets;

public abstract class i0 {
    public static WindowInsets.Builder a(WindowInsets windowInsets0) {
        return new WindowInsets.Builder(windowInsets0);
    }
}

