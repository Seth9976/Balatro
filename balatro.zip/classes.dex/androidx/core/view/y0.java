package androidx.core.view;

public abstract class y0 {
    public static int a() {
        return 0x80;
    }
}

