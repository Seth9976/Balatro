package androidx.core.view;

import android.view.View;

public interface p extends o {
    void d(View arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int[] arg7);
}

