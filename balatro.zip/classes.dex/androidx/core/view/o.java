package androidx.core.view;

import android.view.View;

public interface o {
    void a(View arg1, View arg2, int arg3, int arg4);

    void b(View arg1, int arg2);

    void c(View arg1, int arg2, int arg3, int[] arg4, int arg5);

    void e(View arg1, int arg2, int arg3, int arg4, int arg5, int arg6);

    boolean f(View arg1, View arg2, int arg3, int arg4);
}

