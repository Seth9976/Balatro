package androidx.core.view;

public abstract class u0 {
    public static int a() {
        return 8;
    }
}

