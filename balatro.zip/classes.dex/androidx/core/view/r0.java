package androidx.core.view;

public abstract class r0 {
    public static int a() {
        return 1;
    }
}

