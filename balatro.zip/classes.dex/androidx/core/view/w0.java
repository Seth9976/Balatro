package androidx.core.view;

public abstract class w0 {
    public static int a() {
        return 0x20;
    }
}

