package androidx.core.view;

import android.view.WindowInsets.Builder;

public abstract class h0 {
    public static WindowInsets.Builder a() {
        return new WindowInsets.Builder();
    }
}

