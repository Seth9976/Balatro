package androidx.core.view;

import android.view.KeyEvent;
import android.view.View.OnUnhandledKeyEventListener;
import android.view.View;

public final class w implements View.OnUnhandledKeyEventListener {
    public w(p v$p0) {
    }

    @Override  // android.view.View$OnUnhandledKeyEventListener
    public final boolean onUnhandledKeyEvent(View view0, KeyEvent keyEvent0) {
        throw null;
    }
}

