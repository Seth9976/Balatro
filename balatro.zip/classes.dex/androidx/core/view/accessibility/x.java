package androidx.core.view.accessibility;

public interface x {
    public static abstract class a {
    }

    public static abstract class b extends a {
    }

    public static abstract class c extends a {
    }

    public static abstract class d extends a {
    }

    public static abstract class e extends a {
    }

    public static abstract class f extends a {
    }

    public static abstract class g extends a {
    }

    public static abstract class h extends a {
    }

}

