package androidx.core.view.accessibility;

public class v {
    private final Object a;

    public v(Object object0) {
        this.a = object0;
    }

    public Object a() {
        return this.a;
    }
}

