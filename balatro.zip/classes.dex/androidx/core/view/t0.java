package androidx.core.view;

public abstract class t0 {
    public static int a() {
        return 4;
    }
}

