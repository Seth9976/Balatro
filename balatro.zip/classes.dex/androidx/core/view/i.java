package androidx.core.view;

public interface i {
    void f(l arg1);

    void g(l arg1);
}

