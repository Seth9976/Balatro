package androidx.core.view;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public interface l {
    void a(Menu arg1, MenuInflater arg2);

    void b(Menu arg1);

    boolean c(MenuItem arg1);

    void d(Menu arg1);
}

