package androidx.core.view;

public abstract class v0 {
    public static int a() {
        return 16;
    }
}

