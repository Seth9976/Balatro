package androidx.core.view;

public abstract class k0 {
}

