package androidx.core.view;

public abstract class x0 {
    public static int a() {
        return 0x40;
    }
}

