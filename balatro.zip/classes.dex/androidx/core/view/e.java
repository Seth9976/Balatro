package androidx.core.view;

import android.view.Gravity;

public abstract class e {
    public static int a(int v, int v1) {
        return Gravity.getAbsoluteGravity(v, v1);
    }
}

