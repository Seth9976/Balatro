package androidx.core.view;

public abstract class s0 {
    public static int a() {
        return 2;
    }
}

