package androidx.core.app;

public abstract class q {
    public static void a() {
    }
}

