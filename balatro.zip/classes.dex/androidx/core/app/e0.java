package androidx.core.app;

import androidx.core.util.a;

public interface e0 {
    void e(a arg1);

    void n(a arg1);
}

