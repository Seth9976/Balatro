package androidx.core.app;

import android.content.res.Configuration;

public final class f0 {
    private final boolean a;
    private final Configuration b;

    public f0(boolean z) {
        this.a = z;
        this.b = null;
    }

    public f0(boolean z, Configuration configuration0) {
        this.a = z;
        this.b = configuration0;
    }

    public boolean a() {
        return this.a;
    }
}

