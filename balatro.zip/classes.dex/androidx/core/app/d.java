package androidx.core.app;

import android.content.res.Configuration;

public final class d {
    private final boolean a;
    private final Configuration b;

    public d(boolean z) {
        this.a = z;
        this.b = null;
    }

    public d(boolean z, Configuration configuration0) {
        this.a = z;
        this.b = configuration0;
    }

    public boolean a() {
        return this.a;
    }
}

