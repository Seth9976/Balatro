package androidx.core.app;

import androidx.core.util.a;

public interface d0 {
    void j(a arg1);

    void m(a arg1);
}

