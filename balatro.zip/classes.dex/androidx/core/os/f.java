package androidx.core.os;

import java.util.Locale;

interface f {
    Object a();

    Locale get(int arg1);
}

