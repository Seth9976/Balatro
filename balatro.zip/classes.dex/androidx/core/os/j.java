package androidx.core.os;

import android.os.LocaleList;

public abstract class j {
    public static LocaleList a(Object object0) [...] // Inlined contents
}

