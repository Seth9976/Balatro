package androidx.appcompat.view.menu;

public interface j {
    public interface a {
        boolean c();

        void d(f arg1, int arg2);

        f getItemData();
    }

}

