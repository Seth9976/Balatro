package androidx.appcompat.view.menu;

import android.content.Context;

public interface i {
    public interface a {
        void a(e arg1, boolean arg2);

        boolean b(e arg1);
    }

    void a(e arg1, boolean arg2);

    boolean c();

    void d(Context arg1, e arg2);

    boolean e(e arg1, f arg2);

    boolean h(e arg1, f arg2);

    void i(a arg1);

    boolean j(m arg1);

    void k(boolean arg1);
}

