package androidx.appcompat.view.menu;

import android.widget.ListView;

public interface k {
    void b();

    void dismiss();

    boolean f();

    ListView g();
}

