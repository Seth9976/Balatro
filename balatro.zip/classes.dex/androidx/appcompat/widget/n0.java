package androidx.appcompat.widget;

public final class n0 implements Runnable {
    public final Toolbar e;

    public n0(Toolbar toolbar0) {
        this.e = toolbar0;
    }

    @Override
    public final void run() {
        this.e.d();
    }
}

