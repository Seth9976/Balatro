package androidx.appcompat.widget;

import android.view.MenuItem;
import androidx.appcompat.view.menu.e;

public interface a0 {
    void a(e arg1, MenuItem arg2);

    void c(e arg1, MenuItem arg2);
}

