package androidx.appcompat.widget;

import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.HorizontalScrollView;

public abstract class f0 extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {
}

