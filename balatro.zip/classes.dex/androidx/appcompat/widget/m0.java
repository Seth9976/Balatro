package androidx.appcompat.widget;

public final class m0 implements Runnable {
    public final Toolbar e;

    public m0(Toolbar toolbar0) {
        this.e = toolbar0;
    }

    @Override
    public final void run() {
        this.e.x();
    }
}

