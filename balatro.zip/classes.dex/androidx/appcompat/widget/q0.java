package androidx.appcompat.widget;

public final class q0 implements Runnable {
    public final s0 e;

    public q0(s0 s00) {
        this.e = s00;
    }

    @Override
    public final void run() {
        this.e.e();
    }
}

