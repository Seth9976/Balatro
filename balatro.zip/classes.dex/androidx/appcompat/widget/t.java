package androidx.appcompat.widget;

import android.graphics.drawable.Drawable;
import android.view.Window.Callback;

public interface t {
    void a(int arg1);

    void b(CharSequence arg1);

    void c(Window.Callback arg1);

    CharSequence getTitle();

    void setIcon(int arg1);

    void setIcon(Drawable arg1);
}

